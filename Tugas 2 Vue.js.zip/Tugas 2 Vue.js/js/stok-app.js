var app = new Vue({
  el: '#app',
  data: {
    upbjjList: upbjjList,
    kategoriList: kategoriList,
    stok: JSON.parse(JSON.stringify(stokAwal)),
    filterUpbjj: '',
    filterKategori: '',
    filterStatus: '',
    sortBy: 'judul',
    editKode: '',
    pesan: '',
    error: '',
    form: { kode: '', judul: '', kategori: '', upbjj: '', lokasiRak: '', harga: 0, qty: 0, safety: 0, catatanHTML: '' }
  },
  computed: {
    filteredStok: function() {
      var hasil = this.stok.filter(function(item) {
        var cocokUpbjj = !this.filterUpbjj || item.upbjj === this.filterUpbjj;
        var cocokKategori = !this.filterKategori || item.kategori === this.filterKategori;
        var status = this.statusStok(item);
        var cocokStatus = !this.filterStatus || status === this.filterStatus;
        return cocokUpbjj && cocokKategori && cocokStatus;
      }, this);
      return hasil.sort(function(a, b) {
        if (this.sortBy === 'qty' || this.sortBy === 'harga') return a[this.sortBy] - b[this.sortBy];
        return a.judul.localeCompare(b.judul);
      }.bind(this));
    }
  },
  watch: {
    filterUpbjj: function() {
      this.filterKategori = '';
    },
    filterStatus: function() {
      this.pesan = '';
    }
  },
  methods: {
    formatRupiah: function(nilai) {
      return new Intl.NumberFormat('id-ID', {
        style: 'currency',
        currency: 'IDR',
        maximumFractionDigits: 0
      }).format(nilai || 0);
    },
    statusStok: function(item) {
      if (item.qty === 0) return 'Kosong';
      if (item.qty < item.safety) return 'Menipis';
      return 'Aman';
    },
    statusClass: function(item) {
      return 'status ' + this.statusStok(item).toLowerCase();
    },
    resetFilter: function() {
      this.filterUpbjj = '';
      this.filterKategori = '';
      this.filterStatus = '';
      this.sortBy = 'judul';
    },
    kosongkanForm: function() {
      this.form = { kode: '', judul: '', kategori: '', upbjj: '', lokasiRak: '', harga: 0, qty: 0, safety: 0, catatanHTML: '' };
    },
    editStok: function(item) {
      this.editKode = item.kode;
      this.form = Object.assign({}, item, { catatanHTML: item.catatanHTML.replace(/<[^>]*>/g, '') });
      this.pesan = '';
      this.error = '';
      window.scrollTo({ top: document.body.scrollHeight, behavior: 'smooth' });
    },
    batalEdit: function() {
      this.editKode = '';
      this.kosongkanForm();
      this.error = '';
      this.pesan = '';
    },
    simpanStok: function() {
      this.error = '';
      this.pesan = '';
      if (!this.form.kode || !this.form.judul || !this.form.kategori || !this.form.upbjj || !this.form.lokasiRak) {
        this.error = 'Semua data wajib diisi.';
        return;
      }
      if (this.form.harga < 0 || this.form.qty < 0 || this.form.safety < 0) {
        this.error = 'Harga dan jumlah stok tidak boleh negatif.';
        return;
      }
      if (this.editKode) {
        var index = this.stok.findIndex(function(item) { return item.kode === this.editKode; }.bind(this));
        if (index !== -1) this.$set(this.stok, index, Object.assign({}, this.form));
        this.pesan = 'Data stok berhasil diperbarui.';
        this.editKode = '';
      } else {
        if (this.stok.some(function(item) { return item.kode.toLowerCase() === this.form.kode.toLowerCase(); }.bind(this))) {
          this.error = 'Kode mata kuliah sudah ada.';
          return;
        }
        this.stok.push(Object.assign({}, this.form));
        this.pesan = 'Bahan ajar berhasil ditambahkan.';
      }
      this.kosongkanForm();
    }
  }
});
