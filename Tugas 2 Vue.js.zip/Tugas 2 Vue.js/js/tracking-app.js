var trackingApp = new Vue({
  el: '#trackingApp',
  data: {
    pengirimanList: pengirimanList,
    paket: paket,
    daftarDO: [],
    pesan: '',
    error: '',
    form: { nim: '', nama: '', ekspedisi: '', paketKode: '', tanggalKirim: new Date().toISOString().slice(0, 10) }
  },
  computed: {
    paketTerpilih: function() {
      return this.paket.find(function(item) { return item.kode === this.form.paketKode; }.bind(this)) || null;
    }
  },
  watch: {
    'form.paketKode': function() {
      this.pesan = '';
      this.error = '';
    },
    'form.nim': function() {
      this.form.nim = this.form.nim.replace(/\s/g, '');
    }
  },
  methods: {
    formatRupiah: function(nilai) {
      return new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', maximumFractionDigits: 0 }).format(nilai || 0);
    },
    tambahDO: function() {
      this.pesan = '';
      this.error = '';
      if (!this.form.nim || !this.form.nama || !this.form.ekspedisi || !this.paketTerpilih || !this.form.tanggalKirim) {
        this.error = 'Mohon lengkapi semua data.';
        return;
      }
      var tahun = new Date().getFullYear();
      var nomor = 'DO' + tahun + '-' + String(this.daftarDO.length + 1).padStart(3, '0');
      this.daftarDO.push({
        nomor: nomor,
        nim: this.form.nim,
        nama: this.form.nama,
        ekspedisi: this.form.ekspedisi,
        paketNama: this.paketTerpilih.kode + ' - ' + this.paketTerpilih.nama,
        tanggalKirim: this.form.tanggalKirim,
        total: this.paketTerpilih.harga,
        status: 'Diproses'
      });
      this.pesan = 'DO ' + nomor + ' berhasil dibuat.';
      this.form = { nim: '', nama: '', ekspedisi: '', paketKode: '', tanggalKirim: new Date().toISOString().slice(0, 10) };
    }
  }
});
