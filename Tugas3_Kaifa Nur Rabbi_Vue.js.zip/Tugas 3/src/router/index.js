import { createRouter, createWebHistory } from "vue-router";
import LoginView from "../views/LoginView.vue";
import DashboardView from "../views/DashboardView.vue";
import StockView from "../views/StockView.vue";
import TrackingView from "@/views/TrackingView.vue";


const router = createRouter({
  history: createWebHistory(),
  routes: [
    { path: "/", redirect: "/login" },
    { path: "/login", component: LoginView },
    { path: "/dashboard", component: DashboardView },
    { path: "/stock", component: StockView },
    { path: "/tracking", component: TrackingView },
  ],
});

export default router;